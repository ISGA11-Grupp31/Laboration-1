<?php

namespace App\Http\Controllers;

use App\Models\Movie;
use Illuminate\Http\Request;
//use Illuminate\Validation\Rule;
//use \Illuminate\Database\Eloquent\Builder;

// Kontrollklassen för modellen Movie.
class MoviesController extends Controller {

    // Funktionen körs då endpoint är /test av GET-typ.
    // Vid anrop returneras JSON strängen: { "works": true }.
    public function test() {
        return ['works'=>true];
    }

    // Körs då endpoint är /movies av GET-typ.
    // Returnerar alla filmer i databasen sorterade på titel.
    public function sortByTitle() {
        $post = Movie::orderBy('title', 'asc')->get();
        return $post;
    }

    // Körs då endpoint är /movies/{id} av GET-typ.
    // Tar parameter i form av filmens id.
    // Om filmen med angivet id finns returneras den, annars 404.
    public function getById($id) {
        return Movie::findOrFail($id);
    }

    // Körs då endpoint är /movies av POST-typ.
    // Lägger till en film i databasen baserat på medskickad formulär-data.
    // Vid giltligt anrop returnas { "success": true }.
    public function addMovie(Request $request) {
        $this->validate($request, [
            'title' => 'required',
            'year' => 'integer',
            'genre' => 'alpha_num',
            'rating' => 'integer'
        ]);

        Movie::create( $request->all() );
        return ['success'=>true];
    }

    // Körs då endpoint är /movies/{id} av PUT-typ.
    // Tar parameter i form av filmens id.
    // Ändrar de fält som skickas i formulär-datan på angiven film.
    public function updateMovie(Request $request, $id) {
        $post = Movie::findOrFail($id);

        $data = $this->validate($request, [
            'title' => 'alpha_num',
            'year' => 'integer',
            'genre' => 'alpha_num',
            'rating' => 'integer'
        ]);

        $post->fill($data);
        $post->save();
        return ['success'=>true];
    }

    // Körs då endpoint är /movies/{id} av DELETE-typ.
    // Tar parameter i form av postens id.
    // Tar bort filmen från databasen.
    public function deleteMovie($id) {
        $post = Movie::findOrFail($id);
        $post->delete();
        return ['success'=>true];
    }
}
