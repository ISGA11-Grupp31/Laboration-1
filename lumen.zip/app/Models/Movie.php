<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

// Klass kopplad till tabellen movies i databasen isgb11_lab2.
class Movie extends Model {

    protected $table = 'movies';

    // Anger vilka fält som ska vara påverkningsbara i tabellen.
    protected $fillable = [
        'title',
        'year',
        'genre',
        'rating'
    ];
}
